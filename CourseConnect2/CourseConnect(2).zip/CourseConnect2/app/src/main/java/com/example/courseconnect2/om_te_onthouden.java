package com.example.courseconnect2;

public class om_te_onthouden {
    //valideren in een apparte class zetten zodat we daar ook de database in kunnen zetten

}
