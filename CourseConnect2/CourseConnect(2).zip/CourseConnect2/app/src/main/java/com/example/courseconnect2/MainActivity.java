package com.example.courseconnect2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;


import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    private EditText Name;
    private EditText Password;
    private Button Login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Name = (EditText)findViewById(R.id.idUsername);
        Password = (EditText)findViewById(R.id.idPassword);
        Login = (Button)findViewById(R.id.idLogin);


    }
    public void LoginActie(View view) {
        Validate(Name.getText().toString(), Password.getText().toString());
    }

    public void Validate(String userName, String userPassword) {
        if((userName.equals("w")) && (userPassword.equals("o"))) {
            Intent intent = new Intent(this, Dashboard2.class);
            startActivity(intent);
        }

    }

}
