package com.example.courseconnect2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Switch;


public class RegisterPage extends AppCompatActivity {

    DataBaseHelper mDataBaseHelper;

    private EditText UserName;
    private EditText Email;
    private EditText Password;
    public static String EmailOllie;
    public Switch Teacher;
    public String Teach;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_page);

        mDataBaseHelper = new DataBaseHelper(this);

        UserName = (EditText)findViewById(R.id.idRegName);
        Email = (EditText)findViewById(R.id.idRegMail);
        Password = (EditText)findViewById(R.id.idRegPass);
    }
    public void CheckTeacher(View view) {
        Switch Teacher = (Switch) findViewById(R.id.TeacherSwitch);
        if (Teacher.isChecked()) {
            Teach = "1";
            toastMessage("User is an teacher");
        }else{
            Teach = "0";
            toastMessage("User is not an teacher");
        }

    }


    public void RegisterActie(View view) {
        Switch Teacher = (Switch) findViewById(R.id.TeacherSwitch);
        String givenName = UserName.getText().toString();
        String givenPassword = Password.getText().toString();
        String givenMail = Email.getText().toString();
        EmailOllie = givenMail;

        if(mDataBaseHelper.testName(givenName)) {
            mDataBaseHelper.addData(givenName, givenPassword, givenMail);
            toastMessage("Data (Successfully) Inserted!");

            Intent OpenDB = new Intent(this, Dashboard2.class);
            startActivity(OpenDB);
            MainActivity.UserNameOllie = givenName;
        }else{
            toastMessage(String.format("Unfortunately the username '%s' is already in use", givenName));
        }
    }



    // Message Display
    private void toastMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }







}