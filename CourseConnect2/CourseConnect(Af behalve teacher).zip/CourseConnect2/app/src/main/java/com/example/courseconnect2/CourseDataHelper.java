package com.example.courseconnect2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class CourseDataHelper extends SQLiteOpenHelper {

    public static final String TABLE_NAME = "course_table";
    public static final String TAG = "CourseDataHelper";

    public static final String COURSE_TABLE = "COURSE_TABLE";
    public static final String COLUMN_COURSE_NAME = "COURSE_NAME";
    public static final String COLUMN_COURSE_TEACHER = "COURSE_TEACHER";;
    public static final String COLUMN_COURSE_COSTS = "COURSE_COSTS";;
    public static final String COLUMN_COURSE_ID = "rowid";

    public CourseDataHelper(Context context) {
        super(context, COURSE_TABLE, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable;
        createTable = "CREATE TABLE " + COURSE_TABLE + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_COURSE_NAME + " TEXT, " + COLUMN_COURSE_TEACHER + " TEXT, " + COLUMN_COURSE_COSTS + " INT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
            db.execSQL("DROP TABLE IF EXISTS " + COURSE_TABLE);
            onCreate(db);
    }
    // Add Data to the Database
    public void addCourseData(String name, String costs) {
        SQLiteDatabase db = this.getWritableDatabase();
        String teacher = MainActivity.UserNameOllie;
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_COURSE_NAME, name);
        contentValues.put(COLUMN_COURSE_TEACHER, teacher);
        contentValues.put(COLUMN_COURSE_COSTS, costs);

        Log.d(TAG, "addData: Adding " + name + " to " + COURSE_TABLE);
        Log.d(TAG, "addData: Adding " + teacher + " to " + COURSE_TABLE);
        Log.d(TAG, "addData: Adding " + costs + " to " + COURSE_TABLE);

        //long result =
        db.insert(COURSE_TABLE, null, contentValues);
    }
    public boolean testName(String CourseName) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT " + COLUMN_COURSE_COSTS + " FROM " + TABLE_NAME + " WHERE " + COLUMN_COURSE_NAME + " = '" + CourseName + "'";
        Cursor data = db.rawQuery(query, null);
        String str = "Failed";
        if (data.moveToFirst()) {
            return false;
        }else{
            return true;
        }
    }

    public String getCourseAmount() {
        SQLiteDatabase db = this.getWritableDatabase();
            String query9 = "SELECT COUNT(*) FROM " + TABLE_NAME;;
            Cursor data = db.rawQuery(query9, null);
        String str = "Failed";
        if (data.moveToFirst()) {
            str = data.getString(0);
        }
        return str;
    }

    public String getCourseName(String ID) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT " + COLUMN_COURSE_NAME + " FROM " + TABLE_NAME + " WHERE " + COLUMN_COURSE_ID + " = '" + ID + "'";
        Cursor data = db.rawQuery(query, null);
        String str = "Failed";
        if (data.moveToFirst()) {
            str = data.getString(0);
        }
        return str;
    }


    public String getCourseTeacher(String ID) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT " + COLUMN_COURSE_TEACHER + " FROM " + TABLE_NAME + " WHERE " + COLUMN_COURSE_ID + " = '" + ID + "'";
        Cursor data = db.rawQuery(query, null);
        String str = "Failed";
        if (data.moveToFirst()) {
            str = data.getString(0);
        }
        return str;
    }


    public String getCourseCost(String ID) {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT " + COLUMN_COURSE_COSTS + " FROM " + TABLE_NAME + " WHERE " + COLUMN_COURSE_ID + " = '" + ID + "'";
        Cursor data = db.rawQuery(query, null);
        String str = "Failed";
        if (data.moveToFirst()) {
            str = data.getString(0);
        }
        return str;
    }

}
