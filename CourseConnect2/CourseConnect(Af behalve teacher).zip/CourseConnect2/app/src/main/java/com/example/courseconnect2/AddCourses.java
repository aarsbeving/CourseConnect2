package com.example.courseconnect2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.solver.widgets.Helper;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AddCourses extends AppCompatActivity {

    CourseDataHelper HelperHarry;

    private EditText Name;
    private EditText Costs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_courses);

        HelperHarry = new CourseDataHelper(this);

        Name = (EditText)findViewById(R.id.FillName);
        Costs = (EditText)findViewById(R.id.FillCosts);
    }



    public void RegisterActie(View view) {
        String givenName = Name.getText().toString();
        String givenCosts = Costs.getText().toString();

        if(HelperHarry.testName(givenName)) {
            HelperHarry.addCourseData(givenName, givenCosts);
            toastMessage("Data (Successfully) Inserted!");

            Intent WouterBerendFaxSchuit = new Intent(this, MyCourses.class);
            startActivity(WouterBerendFaxSchuit);
        }else{
            toastMessage(String.format("Unfortunately the username '%s' is already in use", givenName));
        }
    }



    private void toastMessage(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

}